
import { test, expect } from '@playwright/test';
import { ApiHelper } from '../../utils/ApiHelper';
import { bookingTestData } from '../../test-data/bookingTestData';
import * as allure from 'allure-js-commons';

const API_URL = 'https://restful-booker.herokuapp.com';

test.describe('Restful Booker PUT and PATCH API Tests', () => {

  // API-005: Update complete booking using PUT
  test('API-005: Update complete booking using PUT', async ({ request }) => {

    await allure.feature('API Testing');
    await allure.story('PUT Complete Booking Update');
    await allure.severity('critical');
    await allure.description(
      'Verify that an authenticated user can update all booking fields using the PUT method.'
    );

    let bookingId: number;
    let responseBody: any;

    const updatedBooking = {
      firstname: 'Namra Updated',
      lastname: 'Kanwal Updated',
      totalprice: 2500,
      depositpaid: true,
      bookingdates: {
        checkin: '2026-11-10',
        checkout: '2026-11-15'
      },
      additionalneeds: 'Lunch'
    };

    await allure.step('Generate authentication token', async () => {
      const token = await ApiHelper.generateAuthToken(request);
      expect(token).toBeTruthy();

      // Keep token available for the update request
      authToken = token;
    });

    await allure.step('Create a booking for PUT update', async () => {
      const createResponse = await request.post(`${API_URL}/booking`, {
        data: bookingTestData.validBooking
      });

      expect(createResponse.status()).toBe(200);

      const createdBooking = await createResponse.json();
      bookingId = createdBooking.bookingid;

      console.log('\nCreated Booking ID:', bookingId);
    });

    await allure.step('Send PUT request with complete updated booking', async () => {
      const response = await request.put(
        `${API_URL}/booking/${bookingId}`,
        {
          headers: {
            Cookie: `token=${authToken}`,
            Accept: 'application/json'
          },
          data: updatedBooking
        }
      );

      responseBody = await response.json();

      console.log('\n========== API-005 PUT RESPONSE ==========');
      console.log('Booking ID:', bookingId);
      console.log('HTTP Status:', response.status());
      console.log('Updated Request Payload:');
      console.log(JSON.stringify(updatedBooking, null, 2));
      console.log('Response Body:');
      console.log(JSON.stringify(responseBody, null, 2));
      console.log('==========================================\n');

      expect(response.status()).toBe(200);
    });

    await allure.step('Verify all updated booking fields', async () => {
      expect(responseBody.firstname).toBe(updatedBooking.firstname);
      expect(responseBody.lastname).toBe(updatedBooking.lastname);
      expect(responseBody.totalprice).toBe(updatedBooking.totalprice);
      expect(responseBody.additionalneeds).toBe(updatedBooking.additionalneeds);
    });

  });


  // API-006: Update selected booking fields using PATCH
  test('API-006: Update selected booking fields using PATCH', async ({ request }) => {

    await allure.feature('API Testing');
    await allure.story('PATCH Partial Booking Update');
    await allure.severity('critical');
    await allure.description(
      'Verify that an authenticated user can update selected booking fields using PATCH while other fields remain unchanged.'
    );

    let bookingId: number;
    let responseBody: any;

    const partialUpdate = {
      firstname: 'Namra PATCH Updated',
      totalprice: 3000
    };

    let authToken: string;

    await allure.step('Generate authentication token', async () => {
      authToken = await ApiHelper.generateAuthToken(request);
      expect(authToken).toBeTruthy();
    });

    await allure.step('Create a booking for PATCH update', async () => {
      const createResponse = await request.post(`${API_URL}/booking`, {
        data: bookingTestData.validBooking
      });

      expect(createResponse.status()).toBe(200);

      const createdBooking = await createResponse.json();
      bookingId = createdBooking.bookingid;

      console.log('\nCreated Booking ID:', bookingId);
    });

    await allure.step('Send PATCH request with selected fields', async () => {
      const response = await request.patch(
        `${API_URL}/booking/${bookingId}`,
        {
          headers: {
            Cookie: `token=${authToken}`,
            Accept: 'application/json'
          },
          data: partialUpdate
        }
      );

      responseBody = await response.json();

      console.log('\n========== API-006 PATCH RESPONSE ==========');
      console.log('Booking ID:', bookingId);
      console.log('HTTP Status:', response.status());
      console.log('Partial Update Payload:');
      console.log(JSON.stringify(partialUpdate, null, 2));
      console.log('Response Body:');
      console.log(JSON.stringify(responseBody, null, 2));
      console.log('============================================\n');

      expect(response.status()).toBe(200);
    });

    await allure.step('Verify updated fields and unchanged fields', async () => {
      expect(responseBody.firstname).toBe(partialUpdate.firstname);
      expect(responseBody.totalprice).toBe(partialUpdate.totalprice);

      // Verify fields not included in PATCH remain unchanged
      expect(responseBody.lastname).toBe(
        bookingTestData.validBooking.lastname
      );

      expect(responseBody.additionalneeds).toBe(
        bookingTestData.validBooking.additionalneeds
      );
    });

  });

});
